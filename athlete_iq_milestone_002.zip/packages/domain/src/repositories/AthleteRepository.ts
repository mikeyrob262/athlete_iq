import {Athlete} from '../entities/Athlete';
export interface AthleteRepository{
 save(a:Athlete):Promise<void>;
 findById(id:string):Promise<Athlete|null>;
}