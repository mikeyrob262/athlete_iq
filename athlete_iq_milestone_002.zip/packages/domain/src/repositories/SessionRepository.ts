import {Session} from '../entities/Session';
export interface SessionRepository{
 save(session:Session):Promise<void>;
 findById(id:string):Promise<Session|null>;
 findByAthlete(athleteId:string):Promise<Session[]>;
}