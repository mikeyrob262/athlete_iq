export enum GearType {
 Bike='bike',Shoe='shoe',Wheelset='wheelset',PowerMeter='power_meter'
}