export enum SessionType {
 Ride='ride',Run='run',Walk='walk',Strength='strength',Swim='swim',Race='race'
}