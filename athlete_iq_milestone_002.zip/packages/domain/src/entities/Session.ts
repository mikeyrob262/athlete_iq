import {SessionType} from '../enums/SessionType';
export interface Session{
 id:string;
 athleteId:string;
 type:SessionType;
 startedAt:Date;
 durationSeconds:number;
 distanceMeters?:number;
 elevationGainMeters?:number;
 avgHeartRate?:number;
 avgPower?:number;
 gearId?:string;
}