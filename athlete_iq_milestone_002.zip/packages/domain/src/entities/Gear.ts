import {GearType} from '../enums/GearType';
export interface Gear{
 id:string;
 athleteId:string;
 type:GearType;
 name:string;
 manufacturer?:string;
 model?:string;
 purchaseDate?:Date;
 currentMileageKm:number;
}