export interface Athlete {
  id: string;
  firstName: string;
  lastName: string;
  ftp?: number;
  weightKg?: number;
}