export type SessionType =
  | 'ride'
  | 'run'
  | 'walk'
  | 'strength'
  | 'swim'
  | 'race';

export interface Session {
  id: string;
  athleteId: string;
  type: SessionType;
  startedAt: Date;
  durationSeconds: number;
  distanceMeters?: number;
  elevationGainMeters?: number;
}