# Athlete IQ

Milestone 001 - Project scaffold

Stack:
- pnpm
- Turborepo
- Next.js
- Cloudflare Workers
- Prisma
- TypeScript
